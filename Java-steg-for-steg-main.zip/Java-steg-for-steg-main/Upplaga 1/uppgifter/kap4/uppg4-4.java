// Filen Persontest.java

import javax.swing.*;

public class Persontest {
  public static void main(String[] arg) {
    int k�n = JOptionPane.showConfirmDialog(null, "�r du en kille?",
                                "Fr�ga", JOptionPane.YES_NO_OPTION);
    String s = JOptionPane.showInputDialog("Ditt personnummer?");
    String t = s.substring(s.length()-2, s.length()-1);  // n�st sista siffran
    int nr = Integer.parseInt(t);
    if (k�n == 0 && nr%2 == 1 || k�n==1 && nr%2 == 0)
      JOptionPane.showMessageDialog(null, "St�mmer");
    else 
      JOptionPane.showMessageDialog(null, "St�mmer inte");
  }
}
