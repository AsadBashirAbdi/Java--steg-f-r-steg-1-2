  public static int binS�k(Person[] a, int start, int slut, 
                           String s�ktF�rnamn, String S�ktEfternamn) {
  Collator c = Collator.getInstance();
  c.setStrength(Collator.PRIMARY);
   int i1 = start, i2 = slut, m = 0;
   while (i1 <= i2) {
     m = (i1 + i2)/2; 
     if (c.compare(S�ktEfternamn, a[m].efternamn) < 0 || 
         (c.compare(S�ktEfternamn, a[m].efternamn) == 0 && 
          c.compare(s�ktF�rnamn, a[m].f�rnamn) < 0))
       i2 = m-1;
     else if (c.compare(S�ktEfternamn, a[m].efternamn) > 0 || 
         (c.compare(S�ktEfternamn, a[m].efternamn) == 0 && 
          c.compare(s�ktF�rnamn, a[m].f�rnamn) > 0))
       i1 = m+1;
     else // lika
       break;  // man hittade namnet
   }
   if (c.compare(S�ktEfternamn, a[m].efternamn) == 0 && 
       c.compare(s�ktF�rnamn, a[m].f�rnamn) == 0)
     return m;
   else
     return start-1;
  }

