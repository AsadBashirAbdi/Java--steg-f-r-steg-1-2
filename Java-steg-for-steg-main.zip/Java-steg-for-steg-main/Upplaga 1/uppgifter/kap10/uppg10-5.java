// Filen SokText.java

import javax.swing.*;
import java.io.*;  

public class SokText { 
  public static void main(String[] arg) throws IOException {
    String namn1 = JOptionPane.showInputDialog("Vad heter den befintliga filen?");
    BufferedReader instr�m = new BufferedReader
                            (new FileReader(namn1));
    String namn2 = JOptionPane.showInputDialog("Vad skall den nya filen heta?");
    PrintWriter utstr�m = new PrintWriter
                     (new BufferedWriter
                     (new FileWriter(namn2)));
    String txt = JOptionPane.showInputDialog("Vilken text s�ker du?");

    while(true) {
      String s = instr�m.readLine();
      if (s == null)
        break;
      if (s.indexOf(txt) >= 0)
        utstr�m.println(s); 
    }
    instr�m.close();
    utstr�m.close();
  }
}
  
