L�s in det f�rsta talet och tilldela det till en variabel med namnet x.

Upprepa f�ljande ett godtyckligt antal g�nger:
    L�s in ett tal och avbryt upprepningen om anv�ndaren vill sluta.
    Tilldela det inl�sta talet till en variabel med namnet y.
    Om x > y 
        Meddela att talen inte skrivits i storleksordning.
        Avbryt algoritmen.
    annars
        tilldela y till x.     
Meddela att talen skrivits i storleksordning.  
