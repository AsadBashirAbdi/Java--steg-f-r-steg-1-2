// Filen Punkt.java

public class Punkt { 
  double x;
  double y;

  public double avst�nd() {
    return Math.sqrt(x*x + y*y);
  }
}

