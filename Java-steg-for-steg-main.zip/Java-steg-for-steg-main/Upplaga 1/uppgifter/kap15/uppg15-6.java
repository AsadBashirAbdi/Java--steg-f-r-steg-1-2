// Filen Raknare.java

public class Raknare {
  int v�rde, min, max; 

  public void init(int minsta, int st�rsta) {
    min = minsta;
    max = st�rsta;
  }

  public void �ka() {
    if (v�rde < max)
      v�rde++;
    else
      throw new IllegalStateException("F�r stort v�rde i r�knare");
  }

  public void minska() {
    if (v�rde > min)
      v�rde--;
    else
      throw new IllegalStateException("F�r litet v�rde i r�knare");
  }
}

