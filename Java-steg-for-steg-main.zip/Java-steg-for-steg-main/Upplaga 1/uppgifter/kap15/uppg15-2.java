// Filen Punkt.java

public class Punkt { 
  double x;
  double y;

  public void flyttaHorisontellt(double d) {
    x = x + d;
  }

  public void flyttaVertikalt(double d) {
    y = y + d;
  }
}

