// Filen C.java

public class C {

  private static int totAntal = 0;

  public C() {
    totAntal++;
  }

  public static int getAntal() {
    return totAntal;
  }
}


