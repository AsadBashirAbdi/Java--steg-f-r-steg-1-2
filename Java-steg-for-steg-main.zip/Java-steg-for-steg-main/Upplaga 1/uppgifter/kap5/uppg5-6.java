// Filen Kommun.java

import javax.swing.*;

public class Kommun {
  public static void main (String[] arg) {
    String s = JOptionPane.showInputDialog("Vilket �r?");
    int �r = Integer.parseInt(s);
    int antal = 26000;
    for (int i=2013; i<=�r; i++)
      antal = antal + (int) (300 - 325 + antal*(0.7-0.6)/100+0.5);    
    JOptionPane.showMessageDialog(null, "Ber�knad befolkning :" + antal);
  }
}
