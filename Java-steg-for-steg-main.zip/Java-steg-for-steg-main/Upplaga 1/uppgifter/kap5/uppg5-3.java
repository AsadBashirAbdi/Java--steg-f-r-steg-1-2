// Filen Rik.java

import javax.swing.*;

public class Rik {
  public static void main (String[] arg) {
    int antalDagar = 1;
    double dagensL�n = 0.01;
    double totaltBelopp = 0.01; 
    while (totaltBelopp < 10000000) {
      antalDagar++;
      dagensL�n = dagensL�n * 2;
      totaltBelopp = totaltBelopp + dagensL�n;
    }      
    JOptionPane.showMessageDialog(null, "Du m�ste arbeta " + antalDagar + " dagar");
  }
}
