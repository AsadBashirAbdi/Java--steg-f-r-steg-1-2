// Filen ArgDemo2.java 

public class ArgDemo2 {
  public static void main(String[] arg) {
    System.out.println("Antal argument: " + arg.length);
    for (String s : arg)
      System.out.println(s);
  }
} 
