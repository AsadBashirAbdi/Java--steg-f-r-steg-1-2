// Filen Bil.java 

public class Bil {
  String regNr;
  String fabrikat;
  int �rsmodell;
  double tj�nstevikt;
  double effekt;
}

