// Filen Mobil2B.java

import javax.swing.*;

public class Mobil2B {
  public static void main(String[] arg) {
    String[] namn = new String[100];         // f�lt f�r namnen
    int billigast = 0;                       // index f�r billigaste
    double l�gstPris = Double.MAX_VALUE;     // eller ett annat stort v�rde
    // L�s in namn och priser
    int n = 0;    // r�knare f�r antal typer av kort
    while (true) {
      namn[n] = JOptionPane.showInputDialog
                        ("Namn f�r kort nr " + (n+1) +"?");
      if (namn[n] == null)
         break;
      String s = JOptionPane.showInputDialog
                        ("Pris/min f�r " + namn[n] + "?"); 
      if (s == null)
         break;
      double pris = Double.parseDouble(s);
      if (pris < l�gstPris) {
        l�gstPris = pris;
        billigast = n;
      }
      n++;     // �ka antalet typer av kort med 1
    }
    JOptionPane.showMessageDialog
            (null, namn[billigast] + " �r billigast.\n" +
             "Det kostar " + l�gstPris + " / minut");
  }
}
