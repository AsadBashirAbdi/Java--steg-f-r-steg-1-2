Du kan anta att filen mobildata.txt sist p� varje rad inneh�ller priset f�r att skicka ett SMS.
Det tv� f�rsta raderna kan t.ex. ha utseendet:
Natt        79 2,00 0,40  0  0 1,5
Maxring    199 0,99 0,99  0  0 0,6

I programmet deklarerar du ytterligare ett f�lt:
    double[] perSMS    = new double[100];

och i den f�rsta while-satsen l�gger du till en inl�sning till komponenterna f�ltet:
      perSMS[n] = fil.nextDouble();

Fr�ga anv�ndaren hur m�nga SMS skom skickas per m�nad genom att l�gga till raderna:
      String s2 = JOptionPane.showInputDialog
               ("Hur m�nga SMS skickar du per m�nad\n"); 
      if (s2 == null)
        break;
      Scanner input2 = new Scanner(s2);
      double  antalSMS = input2.nextDouble();

F�r att ber�kna kostnaden per m�nad f�r ett visst abonneman l�gger du slutligen till SMS-kostanade.
Satsen blir d�:
        double kostnad = perM�n[i]+ antalDag*perMinDag[i]
                                  + antal�vr*perMin�vr[i]
                                  + antalSMS*perSMS[i];

