// Filen Personnr.java

import javax.swing.*;

public class Personnr {
  public static void main (String[] arg) {
    String s1 = JOptionPane.showInputDialog("Personnumer f�r den f�rsta personen?");
    String s2 = JOptionPane.showInputDialog("Personnumer f�r den andra personen?");
    // plocka ut m�nad och dag
    s1 = s1.substring(2,6);
    s2 = s2.substring(2,6);
    if (s1.equals(s2))
      JOptionPane.showMessageDialog(null, "Samma f�delsedag");
    else
      JOptionPane.showMessageDialog(null, "Olika f�delsedag");
  }
}
