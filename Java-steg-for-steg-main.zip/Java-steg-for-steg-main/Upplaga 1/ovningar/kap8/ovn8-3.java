// �ndra klassen Cirkel s� att den ser ut p� f�ljande s�tt

class Cirkel {
  public static double omkretsen(double r) {
    return 2 * Math.PI * r;
  }

  public static double arean(double r) {
    return Math.PI * r * r;
  }
}
