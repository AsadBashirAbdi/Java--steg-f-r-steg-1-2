// Filen Skott2

import javax.swing.*;

public class Skott2 {
  public static void main(String[] arg) {
    String s = JOptionPane.showInputDialog(
                                       "Skriv ett �rtal");
    int �r = Integer.parseInt(s);
    if (Kalender.�rSkott�r(�r))
      JOptionPane.showMessageDialog(null, "Skott�r");
    else
      JOptionPane.showMessageDialog(null, "Inte skott�r");
  }
}

class Kalender {
  public static boolean �rSkott�r(int n) {
    return (n % 4 == 0 && n % 100 != 0) || n % 400 == 0;
  }
}
