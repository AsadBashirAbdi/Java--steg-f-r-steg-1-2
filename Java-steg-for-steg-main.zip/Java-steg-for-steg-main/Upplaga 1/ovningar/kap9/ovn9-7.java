Om programmet heter TabellOvn s� skall du starta det med f�ljande kommando:

java TabellOvn > fakultet.txt

Efter det att du k�rt programmet kan du  
studera inneh�llet i filen fakultet.txt genom att ge kommandot 

more fakultet.txt

