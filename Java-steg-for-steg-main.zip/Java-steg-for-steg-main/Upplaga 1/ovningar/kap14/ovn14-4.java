I stegen 2.1, 2.2 och 2.1.3: �ndra ordet 'minsta' till 'st�rsta'.

I stegen 2.1.2 och 2.1.2.1: �ndra ordet 'mindre' till 'st�rre'.

