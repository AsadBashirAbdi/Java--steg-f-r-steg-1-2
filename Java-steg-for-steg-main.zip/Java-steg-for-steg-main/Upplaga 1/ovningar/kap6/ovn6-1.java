Anv�nd en variabel summa som s�tts till 0 och en r�knare k som s�tts till 1. 
Upprepa f�ljande tv� rader s� l�nge som k �r mindre �n eller lika med 100:
        L�s in ett tal och tilldela det till en variabel med namnet x        
	�ka summa med x.       
	�ka k med ett. 
Ber�kna uttrycket summa/100 och skriv ut det.  
