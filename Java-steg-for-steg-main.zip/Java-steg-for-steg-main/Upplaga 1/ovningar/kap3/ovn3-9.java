// Filen Slump.java

import javax.swing.*;

public class Slump {
  public static void main (String[] arg) {
    int i = (int) (Math.random() * 100);
    JOptionPane.showMessageDialog(null, "Slumptalet blev: " + i);
  }
}
