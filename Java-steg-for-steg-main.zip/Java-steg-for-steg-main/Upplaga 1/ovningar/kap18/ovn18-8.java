  public void l�ggF�rst(Object nyttElem) { 
    DListElement ny = new DListElement();
    ny.elem = nyttElem;
    ny.n�sta = start.n�sta; 
    ny.f�rra = start;
    start.n�sta.f�rra = ny;
    start.n�sta = ny;
    storlek++;
  }

