Det finns ett stort antal programspr�k med olika egenskaper. Du kan hitta information p� internet.
P� sidan 
http://sv.wikipedia.org/wiki/Programspr%C3%A5k
hittar du l�nkar till information om en massa olika spr�k.


