// Filen Namn.java

import javax.swing.*;

public class Namn {
  public static void main (String[] arg) {
    JOptionPane.showMessageDialog(null, 
                "Linda Johansson\nStorgatan 1\n123456789");
  }
}


