// Filen HejNamn.java

import javax.swing.*;

public class HejNamn {
  public static void main (String[] arg) {
    JOptionPane.showMessageDialog(null, "Hej David!");
    JOptionPane.showMessageDialog(null, "Telefon: 123456789");
  }
}


