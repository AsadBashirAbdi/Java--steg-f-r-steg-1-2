// Filen Hej.java

import javax.swing.*;

public class Hej {
  public static void main (String[] arg) {
    JOptionPane.showMessageDialog(null, "Hej");
  }
}