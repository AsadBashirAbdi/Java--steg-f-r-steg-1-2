// Filen Hej.java

import javax.swing.*;
import java.awt.*;

public class Hej {
  public static void main (String[] arg) {
    JOptionPane.showMessageDialog(null, "Hej!");
    Toolkit.getDefaultToolkit().beep();
  }
}
