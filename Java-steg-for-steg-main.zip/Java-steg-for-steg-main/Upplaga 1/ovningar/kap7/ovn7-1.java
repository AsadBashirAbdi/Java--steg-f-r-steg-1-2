D� kommer programmet fortfarande att visa flera dialogrutor.
Antag t.ex. att man skrivit in texten "123x56789". 
P� f�rsta varvet i for-satsen unders�ker man d� tecknet '1' som �r korrekt.
D�rf�r visas dialogrutan med texten "Talet �r OK".
Detta upprepas p� det andra och det tredje varvet, d�tecknen '2' och '3' unders�ks.
P� fj�rde varvet undes�ks tecknet 'x' som �r felaktigt. D�rf�r visas p� fj�rde
varvet texten "Inget tal". D�refter avbryts for-satsen.
I detta exempel kommer allts� fyra dialogrutor att visas. 
