Man kan �ndra for-satsen s� att den ser ut p� f�ljande s�tt:

    for (int i=1; i<=t.length() && ok; i++)
      if (t.charAt(i) < '0' || t.charAt(i) > '9')
        ok = false;       // inte l�ngre korrekt 

