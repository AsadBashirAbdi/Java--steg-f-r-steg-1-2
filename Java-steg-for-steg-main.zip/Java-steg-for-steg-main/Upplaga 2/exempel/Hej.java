class Hej {
  public static void main (String[] arg) {
    System.out.println("Hej!");
  }
}