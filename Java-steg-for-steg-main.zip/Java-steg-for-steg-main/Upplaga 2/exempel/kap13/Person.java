class Person {
  String f�rnamn;
  String efternamn;
  int f�dd�r;
  Person partner;
}