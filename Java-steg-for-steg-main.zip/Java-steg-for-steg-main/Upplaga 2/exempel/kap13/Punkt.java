class Punkt {
  double x;
  double y;
}