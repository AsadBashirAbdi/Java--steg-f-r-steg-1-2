// Rekommenderat filnamn: Bil.java 

class Bil {
  String regNr;
  String fabrikat;
  int �rsmodell;
  double tj�nstevikt;
  double effekt;
}

