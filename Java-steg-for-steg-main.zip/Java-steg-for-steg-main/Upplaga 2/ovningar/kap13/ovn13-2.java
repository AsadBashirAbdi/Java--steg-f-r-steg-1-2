// Rekommenderat filnamn: BilTest.java 

class BilTest {
  public static void main(String[] arg) {
    Bil b1 = new Bil();
    Bil b2 = new Bil();
  }
}
