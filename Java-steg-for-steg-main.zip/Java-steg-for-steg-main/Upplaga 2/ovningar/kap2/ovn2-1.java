// Rekommenderat filnamn: Variabler.java

class Variabler {
  public static void main (String[] arg) {
    String namn, adress, tel, allt;
    namn = "Erik Andersson";
    adress = "Lilla Gr�nd 4";
    tel = "99999999";
    allt = namn + "\n" + adress + "\n" + tel;
    System.out.println(allt);
  }
}


