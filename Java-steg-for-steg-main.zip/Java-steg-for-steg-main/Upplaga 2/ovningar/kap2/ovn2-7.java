// Rekommenderat filnamn: Ramsa.java

class Ramsa {
  public static void main (String[] arg) {
    String a, b;
    a = "Programspr�k";
    b = a.substring(4, 8) + a.charAt(5); 
    System.out.println(b);
  }
}
