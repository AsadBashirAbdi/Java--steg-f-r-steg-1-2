// Rekommenderat filnamn: Variabler2.java

class Variabler2 {
  public static void main (String[] arg) {
    String namn = "Erik Andersson";
    String adress = "Lilla Gr�nd 4";
    String tel = "99999999";
    String allt = namn + "\n" + adress + "\n" + tel;
    System.out.println(allt);
  }
}

