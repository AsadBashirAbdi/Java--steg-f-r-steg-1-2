// Rekommenderat filnamn: HejNamn.java

class HejNamn {
  public static void main (String[] arg) {
    System.out.println("David");
    System.out.println("Telefon: 123456789");
  }
}


