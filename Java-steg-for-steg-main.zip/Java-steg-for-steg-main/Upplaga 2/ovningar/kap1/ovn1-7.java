// Rekommenderat filnamn: OsNamn.java

class OsNamn {
  public static void main (String[] arg) {
    System.out.println("Du k�r " + System.getProperty("os.name") + " idag");
  }
}


