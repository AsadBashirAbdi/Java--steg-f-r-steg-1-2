// Rekommenderat filnamn: Namn.java

class Namn {
  public static void main (String[] arg) {
    System.out.println("Linda Johansson\nStorgatan 1\n123456789");
  }
}


