// Rekommenderat filnamn: RatTalTest.java

class RatTalTest { 

  public static void main(String[] arg) {
     RatTal r1 = new RatTal();
     RatTal r2 = new RatTal();
     RatTal r3 = new RatTal();
     r1.t�lj = 5; r1.n�mn = 9;
     r2.t�lj = 1; r2.n�mn = 3; 
     r3.t�lj = 7; r3.n�mn = 12;     
  }
}

class RatTal {
  int t�lj;   // t�ljaren
  int n�mn;   // n�mnaren
}