// Rekommenderat filnamn: Punkt.java

class Punkt { 
  double x;
  double y;

  double avst�nd() {
    return Math.sqrt(x*x + y*y);
  }
}

