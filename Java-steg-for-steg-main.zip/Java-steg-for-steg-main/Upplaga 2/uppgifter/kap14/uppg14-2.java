// Rekommenderat filnamn: Punkt.java

class Punkt { 
  double x;
  double y;

  void flyttaHorisontellt(double d) {
    x = x + d;
  }

  void flyttaVertikalt(double d) {
    y = y + d;
  }
}

