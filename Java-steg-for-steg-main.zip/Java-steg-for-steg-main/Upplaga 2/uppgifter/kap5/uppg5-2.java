// Rekommenderat filnamn: Tab.java

class Tab {
  public static void main (String[] arg) {
    String tabell = "";
    for (int i=1; i<=12; i++)
      System.out.println(i + "   " + i*i + "   " + i*i*i);     
  }
}
